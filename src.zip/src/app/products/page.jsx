import React from 'react'
import ProductContainer from './ProductContainer'

function page() {
  return <ProductContainer/>
}

export default page
